import { TodosModel } from './../models/Todos';
import { Component, OnInit } from '@angular/core';
import { TodoService } from 'src/service/todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  activities: TodosModel[];
  constructor(private service: TodoService) {
    this.activities = [];
  }

  ngOnInit() {
    this.activities = this.service.getTodos();
  }
  // addtask
  addTask() {
    this.service.addTask();
  }
  // for delete calling service method
  delete(index: number) {
    this.service.delete(index);
  }
  // for edit calling service method
  edit(name: string) {
    this.service.edit(name);
  }
}
