export class TodosModel{
    public _name:string;
    public _status:string;
    //getter setters
    get name(){
        return this._name;
    }
    set name(tName:string){
        this._name=tName;
    }
    get status(){
        return this._status;
    }
    set status(tstatus:string){
        this._status=tstatus;
    }

}