import { TodoService } from './../../service/todo.service';
import { TodosModel } from './../models/Todos';
import { TodoComponent } from './../todo/todo.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  todoAct: TodosModel;
  constructor(private service: TodoService) {
    this.todoAct = new TodosModel();
  }

  ngOnInit() {
  }
  back() {
    this.service.back();
  }
  addTask() {
    // initially set the Incomplete value to status as per requirement
    this.todoAct.status = "InComplete";
    this.service.enterTask(this.todoAct);
  }
}
