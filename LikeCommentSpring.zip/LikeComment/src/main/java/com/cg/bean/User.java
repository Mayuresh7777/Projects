package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Users")
@SequenceGenerator(name = "usrseq", sequenceName = "user_seq", initialValue = 101, allocationSize = 1)
public class User {
	@Id
	@Column(name = "user_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usrseq")
	private int id;

	@Column(length = 24)
	private String firstName;

	@Column(length = 24)
	private String lastName;

	@Column(length = 64)
	private String email;

	@Column(length = 10)
	private String mobile;

	@Column(length = 24)
	private String password;

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/********** Relationships *************/

	@JsonManagedReference(value = "user-post")
	@OneToMany(mappedBy = "userPost", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Post> posts = new ArrayList<Post>();

	@JsonManagedReference(value = "user-like")
	@OneToMany(mappedBy = "userLike", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Like> likes = new ArrayList<Like>();

	@JsonManagedReference(value = "user-comment")
	@OneToMany(mappedBy = "userComment", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Comment> comments = new ArrayList<Comment>();

	@JsonManagedReference(value = "user-commentReply")
	@OneToMany(mappedBy = "userCommentReply", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<CommentReply> commentReply = new ArrayList<CommentReply>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	public void addPost(Post post) {
		post.setUserPost(this);
		this.getPosts().add(post);
	}

	public List<Like> getLikes() {
		return likes;
	}

	public void setLikes(List<Like> likes) {
		this.likes = likes;
	}

	public void addLike(Like like) {
		like.setUserLike(this);
		this.getLikes().add(like);
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public void addComment(Comment comment) {
		comment.setUserComment(this);
		this.getComments().add(comment);
	}

	public List<CommentReply> getCommentReply() {
		return commentReply;
	}

	public void setCommentReply(List<CommentReply> commentReply) {
		this.commentReply = commentReply;
	}

	public void addCommentReply(CommentReply commentReply) {
		commentReply.setUserCommentReply(this);
		this.getCommentReply().add(commentReply);
	}

}
