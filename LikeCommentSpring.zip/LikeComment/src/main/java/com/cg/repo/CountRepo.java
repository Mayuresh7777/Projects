package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Count;

public interface CountRepo extends CrudRepository<Count, Integer> {

}
