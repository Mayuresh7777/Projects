package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.CommentReply;

public interface CommentReplyRepo extends CrudRepository<CommentReply, Integer> {

}
