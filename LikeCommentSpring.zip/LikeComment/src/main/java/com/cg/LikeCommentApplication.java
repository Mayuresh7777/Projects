package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LikeCommentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LikeCommentApplication.class, args);
	}

}
