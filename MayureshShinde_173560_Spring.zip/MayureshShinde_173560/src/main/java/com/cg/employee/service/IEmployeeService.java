package com.cg.employee.service;

import com.cg.employee.entity.Employee;

public interface IEmployeeService {

	// specify CRUD methods to be override by some another class
	void saveEmployee(Employee emp);

	Employee getById(int id);

	void deleteEmployee(int id);

	Iterable<Employee> findAll();

	Iterable<Employee> findAllByDept(String deptName);
}
