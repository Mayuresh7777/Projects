package com.cg.employee.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//Specifies that the class is an entity
@Entity
// Specifies the table for the annotated entity
@Table(name = "Employee")
public class Employee {
	// Specifies the primary key of an entity.
	@Id
	// Specifies the mapped column for a persistent field.
	@Column(name = "EMP_ID")
	// Provides for the specification of generation strategies for the values of
	// primary keys.
	@GeneratedValue
	private int id;

	// Specifies the mapped column for a persistent field.
	@Column(length = 20)
	private String name;

	// Specifies the mapped column for a persistent field.
	@Column(length = 20)
	private String designation;

	// Specifies the mapped column for a persistent field.
	@Column(name = "DEPT_NAME", length = 25)
	private String deptName;

	private double salary;

	// getters and setter
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
