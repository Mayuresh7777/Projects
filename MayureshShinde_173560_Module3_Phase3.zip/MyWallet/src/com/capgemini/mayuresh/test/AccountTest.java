package com.capgemini.mayuresh.test;

import javax.persistence.NoResultException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.dao.StoreUserdata;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class AccountTest {
	StoreUserdata accountDao = null;

	@Before
	public void setUp() throws Exception {

		accountDao = new StoreUserdata();
	}

	@After
	public void tearDown() throws Exception {
		accountDao = null;
	}

	@Test
	public void testShowbalanceValidDetails() {
		try {
			double amount = accountDao.showBalance(1234501);
			Assert.assertNotNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test(expected=NullPointerException.class)
	public void testShowbalanceInvalidDetails() throws RecordNotFoundException {
			accountDao.showBalance(12345);
	}
	@Test
	public void testDepositValidDetails() {
		try {
			double amount = accountDao.showBalance(1234501);
			accountDao.deposit(1234501, 4000,"Self Deposite");
			double upadatedAmount=accountDao.showBalance(1234501);
			amount+=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testDepositInvalidDetails() {
		try {
			double amount = accountDao.showBalance(1234501);
			accountDao.deposit(1234501, 4000,"Self Deposite");
			Assert.assertFalse(amount==amount+2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawValidDetails() {
		try {
			double amount = accountDao.showBalance(1234501);
			accountDao.withdraw(1234501, 4000,"Self Withdrawal");
			double upadatedAmount=accountDao.showBalance(1234501);
			amount-=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawInvalidDetails() {
		try {
			double amount = accountDao.showBalance(1234501);
			accountDao.withdraw(1234501, 4000,"Self Withdrawal");
			Assert.assertFalse(amount==amount-2000);
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}
}
