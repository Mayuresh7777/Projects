package com.capgemini.mayuresh.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public interface StoreDataInterFace {
	int MIN_BALANCE = 0;

	// creating methods for override
	void openAccount(Account acc);

	boolean validateMobile(long mobile);

	boolean validateEmail(String email);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accID, double amount, String desc) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount, String desc) throws BalanceException,
			RecordNotFoundException;

	void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException;
}
