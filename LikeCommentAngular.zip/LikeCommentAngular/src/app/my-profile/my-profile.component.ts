import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  currentUser : UserModel;
  isEditing:boolean;

  constructor() {
    this.currentUser=new UserModel();
   }
  ngOnInit() {
    this.currentUser=JSON.parse(localStorage.getItem("USER"));
    console.log(this.currentUser);
  }

  edit(){
    this.isEditing=true;
    
  }
}
