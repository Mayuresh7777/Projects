import { Component, OnInit, Input } from '@angular/core';
import { UserModel } from '../models/User';
import { PostModel } from '../models/Post';
import { PostService } from '../service/post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  currentUser: UserModel;

  @Input() post: PostModel;

  constructor(private routes: Router, private postService: PostService) {
    this.currentUser = new UserModel();
    this.post = new PostModel();
  }
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
    console.log(this.currentUser);
  }
  
  posting(content: String) {
    console.log("inside post");
    this.post.content = content;
    console.log(this.post.content);
    console.log(this.currentUser.id);
    if (content.match("[a-zA-Z!@#$%^&*(),.?:{}|<>]{1,100}"))
      this.postService.addPost(this.currentUser.id, this.post).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
  }

}
