import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private routes: Router, private loginService: LoginService) { }

  ngOnInit() {
  }

  logout(){
    console.log("Inside Log Out");
    this.loginService.logout();
    this.routes.navigate(['/login']);
  }
}
