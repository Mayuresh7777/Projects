export class CommentReplyModel {
    public id: number;

    public content: String;
}