import { CommentReplyModel } from './CommentReply';

export class CommentModel {
    public id: number;

    public content: String;

    public reply : Array<CommentReplyModel>;
}