export class CommentModel {
    public id: number;

    public content: String;
}