export class UserModel {
    public id: Number;

    public firstName: String;

    public lastName: String;

    public email: String;

    public mobile: String;

    public password: String;
}