import { CountModel } from './count';


export class PostModel {
    public id: number;

    public content: String;

    public count: CountModel;
}