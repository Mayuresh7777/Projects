import { Component, OnInit, Input } from '@angular/core';
import { CommentModel } from '../models/Comment';
import { CommentService } from '../service/comment.service';
import { UserModel } from '../models/User';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  @Input() comment: CommentModel;

  postId: number;

  currentUser: UserModel;

  comments: CommentModel[] = [];

  map = new Map<number, String>();

  flagMap = new Map<number, boolean>();

  name: String;

  flag: boolean;

  constructor(private commentService: CommentService) {
    this.comment = new CommentModel();
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
  }

  ngOnInit() {
    this.postId = JSON.parse(localStorage.getItem("POSTID"));
    this.fetchComments();
  }

  doComment(content: String) {
    if (content.match("[a-zA-Z!@#$%^&*(),.?:{}|<>]{1,100}")) {
      this.comment.content = content;

      console.log("post id : " + this.postId + " Content : " + this.comment);
      this.commentService.doComment(this.postId, this.currentUser.id, this.comment).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
    }
  }

  fetchComments() {
    console.log("Inside fetch Comment : " + this.postId);
    this.commentService.getComment(this.postId).subscribe(
      data => {
        console.log(data);
        this.setComments(data);
        for (let com of data) {
          this.getName(com.id);
          this.checkUser(com.id);
        }
      },
      error => console.log('ERROR: ' + error));
  }

  setComments(comments: CommentModel[]) {
    this.comments = comments;
  }

  getName(id: number) {
    this.commentService.getName(id).subscribe(
      data => {
        this.setName(data.firstName + " " + data.lastName);
        this.setMap(id, this.name);
        console.log(this.map);
      },
      error => console.log('ERROR: ' + error));
  }

  setName(name: String) {
    this.name = name;
  }

  setMap(id: number, name: String) {
    this.map.set(id, name);
  }
  checkUser(id: number) {
    this.commentService.checkUser(id, this.currentUser.id).subscribe(
      data => {
        this.setFlag(id, data);
      },
      error => console.log('ERROR: ' + error));
  }
  setFlag(id: number, flag: boolean) {
    this.flagMap.set(id, flag);
  }

  unComment(id: number) {
    if(confirm("Press Ok to delete Comment"))
    this.commentService.unComment(this.postId, id).subscribe(
      data => {
        console.log(data);
        window.location.reload();
      },
      error => console.log('ERROR: ' + error));;
  }
}
