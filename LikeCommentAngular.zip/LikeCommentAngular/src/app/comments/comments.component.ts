import { Component, OnInit, Input } from '@angular/core';
import { CommentModel } from '../models/Comment';
import { CommentService } from '../service/comment.service';
import { UserModel } from '../models/User';
import { CommentReplyModel } from '../models/CommentReply';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  @Input() comment: CommentModel;

  @Input() commentReply: CommentReplyModel;

  postId: number;

  currentUser: UserModel;

  comments: CommentModel[] = [];

  reply: CommentReplyModel[] = [];

  map = new Map<number, UserModel>();

  replyNameMap = new Map<number, UserModel>();

  flagMap = new Map<number, boolean>();

  replyFlagMap = new Map<number, boolean>();

  CommentName: String;

  replyFlag: boolean;

  replyMap = new Map<number, CommentReplyModel[]>();

  showDoReply = new Map<number, boolean>();

  constructor(private commentService: CommentService) {
    this.comment = new CommentModel();
    this.commentReply = new CommentReplyModel();
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
  }

  ngOnInit() {
    this.postId = JSON.parse(localStorage.getItem("POSTID"));
    this.fetchComments();
  }

  doComment(content: String) {
    if (content.match("[a-zA-Z!@#$%^&*(),.?:{}|<>]{1,100}")) {
      this.comment.content = content;
      console.log("post id : " + this.postId + " Content : " + this.comment);
      this.commentService.doComment(this.postId, this.currentUser.id, this.comment).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
    }
  }
  doCommentReply(content: String) {
    if (content.match("[a-zA-Z!@#$%^&*(),.?:{}|<>]{1,100}")) {
      this.commentReply.content = content;
      let cId = JSON.parse(localStorage.getItem("REPLYID"));
      this.commentService.doCommentReply(this.postId, this.currentUser.id, cId, this.commentReply).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
    }
  }
  fetchComments() {
    console.log("Inside fetch Comment : " + this.postId);
    this.commentService.getComment(this.postId).subscribe(
      data => {
        console.log(data);
        this.setComments(data);
        for (let com of data) {
          this.getName(com.id);
          this.checkUser(com.id);
          this.fetchReply(com.id, com.reply);
          this.setShowDOReply(com.id);
        }
      },
      error => console.log('ERROR: ' + error));
  }

  setShowDOReply(id: number) {
    this.showDoReply.set(id, false);
  }

  toggleShowDoReply(id: number) {
    this.replyFlag = this.showDoReply.get(id);
    this.comments.forEach(element => {
      this.showDoReply.set(element.id, false);
    });
    this.showDoReply.set(id, !this.replyFlag);
    localStorage.setItem("REPLYID", JSON.stringify(id));
  }
  fetchReply(id: number, reply: CommentReplyModel[]) {
    reply.forEach(element => {
      this.reply.push(element);
      this.setReplierName(element.id);
    });
    this.replyMap.set(id, this.reply);
    this.reply = [];
  }
  setComments(comments: CommentModel[]) {
    this.comments = comments;
  }

  setReplierName(id: number) {
    this.commentService.getReplierName(id).subscribe(
      data => {
        this.setReplierNameMap(id, data);
        this.setReplyFlagMap(id, data);
      },
      error => console.log('ERROR: ' + error));
  }

  setReplyFlagMap(id: number, user: UserModel) {
    if (this.currentUser.id == user.id)
      this.replyFlagMap.set(id, true);
    else
      this.replyFlagMap.set(id, false);
  }
  setReplierNameMap(id: number, user: UserModel) {
    this.replyNameMap.set(id, user);
  }

  getName(id: number) {
    this.commentService.getName(id).subscribe(
      data => {
        this.setMap(id, data);
        console.log(this.map);
      },
      error => console.log('ERROR: ' + error));
  }

  setName(name: String) {
    this.CommentName = name;
  }

  setMap(id: number, user: UserModel) {
    this.map.set(id, user);
  }
  checkUser(id: number) {
    this.commentService.checkUser(id, this.currentUser.id).subscribe(
      data => {
        this.setFlag(id, data);
      },
      error => console.log('ERROR: ' + error));
  }
  setFlag(id: number, flag: boolean) {
    this.flagMap.set(id, flag);
  }

  unComment(id: number) {
    if (confirm("Press Ok to delete Comment"))
      this.commentService.unComment(this.postId, id).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
  }

  uncommentReply(id: number) {
    if (confirm("Press Ok to delete Comment Reply"))
      this.commentService.unCommentReply(this.postId, id).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
  }
}
