import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { UserModel } from '../models/User';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Input() user: UserModel;
  validEmail: boolean;
  validMobile: boolean;
  validPass: boolean;
  sign: boolean;
  @Input() isEditing: boolean;
  @Output() edited = new EventEmitter();


  constructor(private routes: Router, private loginService: LoginService) {
    this.user = new UserModel();
    this.validEmail = false;
    this.validMobile = false;
    this.sign = false;
    this.validPass = false;
  }

  ngOnInit() {
  }

  signup() {
    console.log(this.validEmail || this.validMobile);
    if (!(this.validEmail || this.validMobile)) {
      console.log("Register Successful");
      this.loginService.addUser(this.user).subscribe(data => console.log(data), error => console.log(error));
      this.user = new UserModel();
      window.location.pathname="./login";
    }
    else this.sign = true;
  }

  checkEmail(email: String) {
    console.log("email : " + email);
    if (email != "")
      this.loginService.validateEmail(email).subscribe(
        data => {
          console.log("Email " + data);
          this.setValidEmail(data as boolean);
        }, error => console.log(error));
  }

  checkMobile(mobile: String) {
    if (mobile != "")
      this.loginService.validateMobile(mobile).subscribe(
        data => {
          console.log("Mobile " + data);
          this.setValidMobile(data);
        }, error => console.log(error));

  }

  setValidEmail(flag: boolean) {
    if (!this.isEditing)
      this.validEmail = flag;
    else
      this.validEmail = false;
  }

  setValidMobile(flag: boolean) {
    if (!this.isEditing)
      this.validMobile = flag;
    else
      this.validMobile = false;
  }

  get emailBox(): any {
    if (this.validEmail)
      return { 'border-right': '10px solid red' };
  }

  get mobileBox(): any {
    if (this.validMobile)
      return { 'border-right': '10px solid red' };
  }

  update() {
    this.isEditing = false;
    this.loginService.updateUser(this.user).subscribe(
      data => {
        console.log("Updated User " + data);
        this.loginService.setUser(data);
      }, error => console.log(error));;
    this.edited.emit();
  }

  checkPass(pass: String) {
    if (!pass.match("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{6,}"))
      this.validPass = true;
    else
      this.validPass = false;
  }
  login(){
    window.location.pathname="./login";
  }
}