import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserModel } from '../models/User';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: UserModel;
  constructor(private routes: Router, private loginService: LoginService) {
    this.user = new UserModel();
  }

  ngOnInit() {
  }

  signup() {
    console.log("Register Successful");
    this.loginService.addUser(this.user).subscribe(data => console.log(data), error => console.log(error));
    this.user = new UserModel();
    this.routes.navigate(['/login']);
  }
}
