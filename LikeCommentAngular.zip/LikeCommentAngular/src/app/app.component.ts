import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './service/login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  ngOnInit() {
  }
  title = 'LikeCommentAngular';

  constructor(private routes: Router, private loginService: LoginService) {
  }

  logout() {
    console.log("Inside Log Out");
    this.loginService.logout();
    window.location.pathname="./login";
  }

  profile() {
    this.routes.navigate(['/profile']);
  }
}