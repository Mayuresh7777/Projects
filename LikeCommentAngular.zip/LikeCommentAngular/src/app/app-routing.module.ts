import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './guard/auth.guard';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { PostComponent } from './post/post.component';
import { ShowPostComponent } from './show-post/show-post.component';

const routes: Routes = [
  { path: '', redirectTo: '\login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, pathMatch: 'full' },
  { path: 'register', component: RegisterComponent, pathMatch: 'full' },
  { path: 'home', component: HomeComponent, pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'profile', component: MyProfileComponent, pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'post', component: PostComponent, pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'showPost', component: ShowPostComponent, pathMatch: 'full', canActivate: [AuthGuard] },
  { path: '**', redirectTo: '\login' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: `reload` })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
