import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommentModel } from '../models/Comment';
import { Observable } from 'rxjs';
import { PostModel } from '../models/Post';
import { UserModel } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  private baseUrl = 'http://localhost:7778/comment';

  constructor(private http: HttpClient) { }

  doComment(postId: number, userId: number, comment: CommentModel): Observable<PostModel> {
    return this.http.post<PostModel>(`${this.baseUrl}/${postId}/${userId}`, comment);
  }

  unComment(postId: number, cId: number): Observable<PostModel> {
    return this.http.delete<PostModel>(`${this.baseUrl}/${postId}/${cId}`);
  }

  getComment(postId: number): Observable<CommentModel[]> {
    return this.http.get<CommentModel[]>(`${this.baseUrl}/${postId}`);
  }

  getName(cId: number): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/name/${cId}`);
  }

  checkUser(cId: number, userId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/check/${cId}/${userId}`);
  }
}
