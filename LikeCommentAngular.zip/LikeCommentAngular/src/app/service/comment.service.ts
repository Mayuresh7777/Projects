import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommentModel } from '../models/Comment';
import { Observable } from 'rxjs';
import { PostModel } from '../models/Post';
import { UserModel } from '../models/User';
import { CommentReplyModel } from '../models/CommentReply';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  private baseUrl = 'http://localhost:7778/comment';

  constructor(private http: HttpClient) { }

  doComment(postId: number, userId: number, comment: CommentModel): Observable<PostModel> {
    return this.http.post<PostModel>(`${this.baseUrl}/${postId}/${userId}`, comment);
  }

  doCommentReply(postId: number, userId: number, cId: number, reply: CommentReplyModel): Observable<PostModel> {
    return this.http.post<PostModel>(`${this.baseUrl}/reply/${postId}/${userId}/${cId}`, reply);
  }

  unComment(postId: number, cId: number): Observable<PostModel> {
    return this.http.delete<PostModel>(`${this.baseUrl}/${postId}/${cId}`);
  }

  unCommentReply(postId: number, crId: number): Observable<PostModel> {
    return this.http.delete<PostModel>(`${this.baseUrl}/reply/${postId}/${crId}`);
  }
  getComment(postId: number): Observable<CommentModel[]> {
    return this.http.get<CommentModel[]>(`${this.baseUrl}/${postId}`);
  }

  getName(cId: number): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/name/${cId}`);
  }

  checkUser(cId: number, userId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/check/${cId}/${userId}`);
  }

  getReplierName(crId: number): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/reply/name/${crId}`);
  };
}
