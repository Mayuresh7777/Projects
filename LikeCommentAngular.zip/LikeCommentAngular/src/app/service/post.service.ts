import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostModel } from '../models/Post';
import { Observable } from 'rxjs';
import { UserModel } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  private baseUrl = 'http://localhost:7778/post';

  constructor(private http: HttpClient) { }

  addPost(id: number, post: PostModel): Observable<PostModel> {
    return this.http.post<PostModel>(`${this.baseUrl}/${id}`, post);
  }

  removePost(id: number): Observable<Object>{
    return this.http.delete<Object>(`${this.baseUrl}/${id}`);
  }
  getAll(): Observable<PostModel[]> {
    return this.http.get<PostModel[]>(`${this.baseUrl}/all`);
  }

  getName(id: number): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/name/${id}`);
  }

  checkUser(postId: number, userId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/check/${postId}/${userId}`);
  }

  likedBy(postId: number): Observable<UserModel[]> {
    return this.http.get<UserModel[]>(`${this.baseUrl}/likedby/${postId}`);
  }
}
