import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from '../models/User';

const TOKEN = 'USER';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  user: UserModel;
  

  private baseUrl = 'http://localhost:7778/user';

  constructor(private http: HttpClient) {
    this.user = new UserModel();
  }

  getUser(username: String, pass: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${username}/${pass}`);
  }

  addUser(user: UserModel): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, user);
  }

  validateEmail(email: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/email/${email}`);
  }

  validateMobile(mobile: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/mobile/${mobile}`);
  }

  setUser(user: UserModel){
    this.user=user;
    localStorage.setItem(TOKEN,JSON.stringify(user));
  }

  isLogged(){
    return localStorage.getItem(TOKEN) != null;
  }

  logout(){
    localStorage.removeItem(TOKEN);
  }
}