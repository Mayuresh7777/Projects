package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Comment_Reply")
@SequenceGenerator(name = "cmtrseq", sequenceName = "cmtr_seq", initialValue = 101, allocationSize = 1)
public class CommentReply {

	@Id
	@Column(name = "commentreply_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cmtrseq")
	private int id;

	private String content;

	/********** Relationships *************/

	@JsonBackReference(value = "user-commentReply")
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User userCommentReply;

	@JsonBackReference(value = "comment-reply")
	@ManyToOne
	@JoinColumn(name = "comment_id")
	private Comment comment;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public User getUserCommentReply() {
		return userCommentReply;
	}

	public void setUserCommentReply(User userCommentReply) {
		this.userCommentReply = userCommentReply;
	}

}
