package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "posts")
@SequenceGenerator(name = "postseq", sequenceName = "post_seq", initialValue = 101, allocationSize = 1)
public class Post {

	@Id
	@Column(name = "post_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "postseq")
	private int id;

	private String content;

	/********** Relationships *************/

	@JsonManagedReference(value = "post-like")
	@OneToMany(mappedBy = "postFromLike", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Like> likes = new ArrayList<Like>();

	@JsonManagedReference(value = "post-comment")
	@OneToMany(mappedBy = "postFromComment", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Comment> comments = new ArrayList<Comment>();

	@JsonManagedReference(value = "count")
	@OneToOne(mappedBy = "post", cascade = CascadeType.ALL)
	private Count count;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<Like> getLikes() {
		return likes;
	}

	public void setLikes(List<Like> likes) {
		this.likes = likes;
	}

	public void addLike(Like like) {
		like.setPostFromLike(this);
		this.getLikes().add(like);
	}

	public void unLike(Like like) {
		this.getLikes().remove(like);
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public void addComment(Comment comment) {
		comment.setPostFromComment(this);
		this.getComments().add(comment);
	}

	public void unComment(Comment comment) {
		this.getComments().remove(comment);
	}

	public Count getCount() {
		return count;
	}

	public void setCount(Count count) {
		this.count = count;
	}

}
