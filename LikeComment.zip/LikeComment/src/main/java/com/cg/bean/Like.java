package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Likes")
@SequenceGenerator(name = "lkseq", sequenceName = "like_seq", initialValue = 101, allocationSize = 1)
public class Like {

	@Id
	@Column(name = "like_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "lkseq")
	private int id;

	@Column(length = 50)
	private String name;

	/********** Relationships *************/

	@JsonBackReference(value = "post-like")
	@ManyToOne
	@JoinColumn(name = "post_id")
	private Post postFromLike;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Post getPostFromLike() {
		return postFromLike;
	}

	public void setPostFromLike(Post postFromLike) {
		this.postFromLike = postFromLike;
	}

}
