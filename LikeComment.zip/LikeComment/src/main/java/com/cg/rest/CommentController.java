package com.cg.rest;

import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Comment;
import com.cg.bean.CommentReply;
import com.cg.bean.Count;
import com.cg.bean.Post;
import com.cg.repo.CommentReplyRepo;
import com.cg.repo.CommentRepo;
import com.cg.repo.PostRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/comment")
public class CommentController {

	@Autowired
	PostRepo postRepo;

	@Autowired
	CommentRepo cRepo;

	@Autowired
	CommentReplyRepo crRepo;

	@PostMapping(path = "/{postId}")
	public ResponseEntity<Post> doComment(@PathVariable("postId") int id, @RequestBody Comment comment) {
		Post post = postRepo.findById(id).get();
		post.addComment(comment);
		Count count = post.getCount();
		count.setCommentCount(count.getCommentCount() + 1);
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}

	@DeleteMapping(path = "/{postId}/{id}")
	public ResponseEntity<Post> unComment(@PathVariable("postId") int postId, @PathVariable("id") int cId) {
		Post post = postRepo.findById(postId).get();
		Comment comment = cRepo.findById(cId).get();
		post.unComment(comment);
		Count count = post.getCount();
		count.setCommentCount(count.getCommentCount() - 1);
		List<CommentReply> replies = comment.getReply();
		long counts = StreamSupport.stream(replies.spliterator(), false).count();
		if (counts != 0) {
			count.setCommentCount(count.getCommentCount() - counts);
		}
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}

	@PostMapping(path = "/reply/{postId}/{cId}")
	public ResponseEntity<Post> commentReply(@PathVariable("postId") int postId, @PathVariable("cId") int cId,
			@RequestBody CommentReply reply) {
		Post post = postRepo.findById(postId).get();
		Comment comment = cRepo.findById(cId).get();
		comment.addReply(reply);
		Count count = post.getCount();
		count.setCommentCount(count.getCommentCount() + 1);
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}

	@DeleteMapping(path = "/reply/{postId}/{cId}/{crId}")
	public ResponseEntity<Post> uncommentReply(@PathVariable("postId") int postId, @PathVariable("cId") int cId,
			@PathVariable("crId") int crId) {
		Post post = postRepo.findById(postId).get();
		Comment comment = cRepo.findById(cId).get();
		CommentReply reply = crRepo.findById(crId).get();
		crRepo.delete(reply);
		Count count = post.getCount();
		count.setCommentCount(count.getCommentCount() - 1);
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}
}