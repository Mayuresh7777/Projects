package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Count;
import com.cg.bean.Post;
import com.cg.repo.PostRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/post")
public class PostController {

	@Autowired
	PostRepo postRepo;

	@PostMapping(path = "", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Post> addPost(@RequestBody Post post) {
		post = postRepo.save(post);
		Count count = new Count();
		count.setPost(post);
		post.setCount(count);
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}

	@PutMapping(path = "", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Post> updatePost(@RequestBody Post post) {
		return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
	}

	@GetMapping(path = "/{id}", produces = "application/json")
	public ResponseEntity<Post> getPost(@PathVariable int id) {
		return new ResponseEntity<Post>(postRepo.findById(id).get(), HttpStatus.OK);
	}

	@GetMapping(path = "/all", produces = "application/json")
	public ResponseEntity<Iterable<Post>> getAllPost() {
		return new ResponseEntity<Iterable<Post>>(postRepo.findAll(), HttpStatus.OK);
	}

	@GetMapping(path = "/count/{id}", produces = "application/json")
	public Count getCount(@PathVariable int id) {
		Post post = postRepo.findById(id).get();
		return post.getCount();
	}
	
}
