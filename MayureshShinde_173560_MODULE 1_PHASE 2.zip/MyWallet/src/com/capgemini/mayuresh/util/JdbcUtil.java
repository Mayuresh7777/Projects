package com.capgemini.mayuresh.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class JdbcUtil {
	private static Connection connection = null;

	public static Connection getConnection() {

		File file = null;
		FileInputStream inputStream = null;

		file = new File("C:\\Users\\mayuress\\workspace\\MyWallet\\resources\\jdbc.properties");
		try {
			inputStream = new FileInputStream(file);

			Properties properties = new Properties();
			properties.load(inputStream);

			//String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			//Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
			//System.out.println("Connection Established");
		} catch (Exception e) {
			System.out.println(e);
		} finally{
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return connection;
	}
}