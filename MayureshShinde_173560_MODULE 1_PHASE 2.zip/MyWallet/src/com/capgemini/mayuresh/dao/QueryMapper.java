package com.capgemini.mayuresh.dao;

public interface QueryMapper {
	String insertDetails = "Insert into account values(seq_accno.nextval,?,?,?,?,?)";
	String depositBalance = "update account set balance=balance+? where accno=?";
	String withdrawBalance = "update account set balance=balance-? where accno=?";
	String getMax = "select max(accno) from account";
	String UserNameAndPassword = "select * from account where email=?";
	String getBalance = "select balance from account where accno=?";
	String acc = "select accno from account where accno=?";
	String transaction = "insert into transaction values (seq_trans.nextval,?,?,?,?)";
	String ShowTrans = "select * from transaction where accno=? order by id";
	String validateEmail = "select email from account where email=?";
	String validateMobile = "select mobile from account where mobile=?";
	// String all="select * from account";
}
