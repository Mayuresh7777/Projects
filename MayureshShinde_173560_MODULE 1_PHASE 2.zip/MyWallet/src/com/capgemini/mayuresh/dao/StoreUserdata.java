package com.capgemini.mayuresh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.bean.Transaction;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;
import com.capgemini.mayuresh.util.JdbcUtil;

public class StoreUserdata implements StoreDataInterFace, QueryMapper {
	public Account validateUsernameAndPassword(String userName, String password)
			throws RecordNotFoundException {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		Account acc = new Account();
		try {
			statement = connection
					.prepareStatement(QueryMapper.UserNameAndPassword);
			// select * from account where email=?
			// putting usernamme(email) at ? to get all the details
			statement.setString(1, userName);

			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				if (rs.getInt("ACCNO") != 0) {
					String pass = rs.getString("PASSWORD");
					if (pass.equals(password)) {
						acc.setAccNo(rs.getInt("ACCNO"));
						acc.setName(rs.getString("NAME"));
						acc.setEmail(rs.getString("EMAIL"));
						return acc;// if password match then return acc details
					}
					rs.close();
				}
			}
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		throw new RecordNotFoundException(
				"Accound Does Not Exist.\nOpen Account First");
	}

	@Override
	public void openAccount(Account acc) {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		acc.setBalance(1000);
		connection = JdbcUtil.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.insertDetails);
			statement.setString(1, acc.getName());
			statement.setLong(2, acc.getMobile());
			statement.setString(3, acc.getEmail());
			statement.setString(4, acc.getPassword());
			statement.setDouble(5, acc.getBalance());
			statement.executeUpdate();// inserting all details in table
			System.out.println("Customer information saved successfully.");
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}

	@Override
	public double showBalance(int accId) throws RecordNotFoundException {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.getBalance);
			statement.setLong(1, accId);

			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				return rs.getDouble("BALANCE");
			} else
				throw new RecordNotFoundException(
						"Accound Record not found.\nFirst Open Account");

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}

	@Override
	public void deposit(int accID, double amount)
			throws RecordNotFoundException {
		if (checkAccId(accID) == accID) {
			Connection connection = JdbcUtil.getConnection();
			PreparedStatement statement = null;
			try {
				statement = connection
						.prepareStatement(QueryMapper.depositBalance);
				statement.setLong(2, accID);
				statement.setDouble(1, amount);

				statement.executeUpdate();
				insertIntoTrans(accID, "CR", amount, showBalance(accID));
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);

			} finally {
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println(e);
				}

				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println(e);
				}
			}
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	public int checkAccId(int id) throws RecordNotFoundException {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.acc);
			statement.setLong(1, id);

			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			} else
				throw new RecordNotFoundException("Accound Record not found.");

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			return 0;
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}

	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.ShowTrans);
			statement.setLong(1, userAccId);

			ResultSet rs = statement.executeQuery();
			System.out.println("Type\tAmount\tBalance");
			while (rs.next()) {
				System.out.println(rs.getString("type") + "\t"
						+ rs.getDouble("amount") + "\t"
						+ rs.getDouble("balance"));
			}
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}

	@Override
	public void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException {
		double amt = showBalance(accId);
		if (amt >= amount) {
			Connection connection = JdbcUtil.getConnection();
			PreparedStatement statement = null;
			try {
				statement = connection
						.prepareStatement(QueryMapper.withdrawBalance);
				statement.setLong(2, accId);
				statement.setDouble(1, amount);

				statement.executeUpdate();
				insertIntoTrans(accId, "DR", amount, amt - amount);
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} finally {
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println(e);
				}

				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println(e);
				}
			}
		} else
			throw new BalanceException("Insufficient Balance");
	}

	public void fundTransfer(int source, int target, double amount)
			throws RecordNotFoundException, BalanceException {
		if (showBalance(source) >= amount) {
			deposit(target, amount);
			withdraw(source, amount);
		}else
			throw new BalanceException("Insufficient Balance");
	}

	public boolean validateMobile(long mobile) {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.validateMobile);
			statement.setLong(1, mobile);

			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				if (rs.getLong("MOBILE") == mobile)
					return false;
			}
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return true;
	}

	public boolean validateEmail(String email) {
		// for (Account acc : accounts.values()) {
		// if (email.equals(acc.getEmail())) {
		// return false;
		// }
		// }
		// return true;
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.validateEmail);
			statement.setString(1, email);

			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				if (rs.getString("EMAIL").equals(email)) {
					return false;
				}
			}
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return true;
	}

	public void insertIntoTrans(int accId, String type, double amount,
			double balance) {
		Connection connection = JdbcUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(QueryMapper.transaction);
			statement.setLong(1, accId);
			statement.setString(2, type);
			statement.setDouble(3, amount);
			statement.setDouble(4, balance);
			statement.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}
}
