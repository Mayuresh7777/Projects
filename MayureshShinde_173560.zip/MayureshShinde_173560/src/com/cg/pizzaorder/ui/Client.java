package com.cg.pizzaorder.ui;

import java.util.Calendar;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidInputException;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		PizzaOrderService service = new PizzaOrderService();
		final double BASEPIZZAPRICE = 350; // base price of pizza 350 rs.
		// declaring variables to store users details
		String choice;
		String name;
		String mobile;
		String address;
		String topping;
		double price;
		String orderId;
		boolean isValid = false;
		// for continues asking place order,display order,exit
		while (true) {
			// for taking correct input
			while (true) {
				System.out.println("1)	Place Order\n2)	Display Order\n3)	Exit");
				choice = scanner.next();
				try {
					isValid = service.validateEntry(choice);
				} catch (InvalidInputException e) {
					System.out.println(e);
				}
				if (isValid) {
					isValid = false;
					break;// if user enter valid input then break
				}

			}
			switch (choice) {
			case "1":
				System.out.println("Pizza Toppings \t Price (in Rs)");
				System.out
						.println("Capsicum \t 30\nMushroom \t 50\nJalapeno \t 70\nPaneer \t\t 85");
				while (true) {

					System.out.println("Enter the name of the customer");
					name = scanner.next();

					// to validate UserName
					try {
						isValid = service.validateUserName(name);
					} catch (InvalidInputException e) {
						System.out.println(e);
					}
					if (isValid) {
						isValid = false;
						break;// if user enter valid input then break
					}
				}
				while (true) {

					System.out.println("Enter customer address");
					address = scanner.next();
					// to validate user Address
					try {
						isValid = service.validateAddress(address);
					} catch (InvalidInputException e) {
						System.out.println(e);
					}
					if (isValid) {
						isValid = false;
						break;// if user enter valid input then break
					}
				}
				while (true) {

					System.out.println("Enter customer phone number");
					mobile = scanner.next();
					// to validate user Mobile No
					try {
						isValid = service.validateMobile(mobile);
					} catch (InvalidInputException e) {
						System.out.println(e);
					}
					if (isValid) {
						isValid = false;
						break;// if user enter valid input then break
					}
				}
				while (true) {

					System.out.println("Type of pizza Topping preffered");
					topping = scanner.next();
					// to set topping price
					if (topping.equalsIgnoreCase("Capsicum")) {
						price = 30;
						break;
					} else if (topping.equalsIgnoreCase("Mushroom")) {
						price = 50;
						break;
					} else if (topping.equalsIgnoreCase("jalapeno")) {
						price = 70;
						break;
					} else if (topping.equalsIgnoreCase("Paneer")) {
						price = 50;
						break;
					} else
						System.out.println("Enter Valid Topping");
				}
				System.out.println("Price : " + (BASEPIZZAPRICE + price));
				System.out.println("Order Date :"
						+ Calendar.getInstance().get(Calendar.DATE) + "/"
						+ Calendar.getInstance().get(Calendar.MONTH) + "/"
						+ Calendar.getInstance().get(Calendar.YEAR) + "  "
						+ Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
						+ ":" + Calendar.getInstance().get(Calendar.MINUTE)
						+ ":" + Calendar.getInstance().get(Calendar.SECOND));
				// int custId = (int) (Math.random() * 1000);
				// int orderId = (int) (Math.random() * 1000);
				Customer customer = new Customer(name, address, mobile);
				PizzaOrder pizza = new PizzaOrder();
				pizza.setTotalPrice(BASEPIZZAPRICE + price);
				int id = 0;
				try {
					id = service.placeOrder(customer, pizza);
					System.out
							.println("Pizza order successfully placed with order id :"
									+ id);
				} catch (PizzaException e1) {
					System.out.println(e1);
					;
				}

				break;
			case "2":
				while (true) {
					System.out
							.println("enter the order Id to display order Details");
					orderId = scanner.next();
					try {
						isValid = service.validateOrderId(orderId);
					} catch (InvalidInputException e) {
						System.out.println(e);
					}
					if (isValid) {
						isValid = false;
						break;// if user enter valid input then break
					}
				}
				try {
					System.out.println(service.getorderdetails(Integer.parseInt(orderId)));
				} catch (PizzaException e) {
					System.out.println(e);

				}
				break;

			case "3":
				System.exit(0);
				break;
			default:
				break;
			}
		}
	}
}
