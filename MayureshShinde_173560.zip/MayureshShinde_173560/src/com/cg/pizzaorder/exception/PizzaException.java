package com.cg.pizzaorder.exception;

public class PizzaException extends Exception {
	public PizzaException() {
	}
	public PizzaException(String msg) {
		super(msg);
	}
}
