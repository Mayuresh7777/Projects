package com.cg.pizzaorder.exception;

public class InvalidInputException extends Exception {
	public InvalidInputException() {
	}
	public InvalidInputException(String msg) {
		super(msg);
	}
}
