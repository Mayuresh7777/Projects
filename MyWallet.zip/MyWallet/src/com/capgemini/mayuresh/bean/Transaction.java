package com.capgemini.mayuresh.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")
public class Transaction {
//	@Override
//	public boolean equals(Object obj) {
//		if (obj instanceof Transaction)
//			return ((Transaction) obj).account == account;
//		else
//			return false;
//	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trans_generator")
	@SequenceGenerator(name = "trans_generator", sequenceName = "seq_trans")
	@Column(name = "id", updatable = false, nullable = false)
	private int id;

	@ManyToOne
	@JoinColumn(name = "ACCNO")
	private Account account;

	@Column(name = "TYPE", length = 2)
	private String type;

	@Column(name = "AMOUNT")
	private double amount;

	@Column(name = "BALANCE")
	private double balance;

	@Column(name = "TIME")
	private String transTime;

	@Column(name = "DESCRIPTION")
	private String description;

	public Transaction() {
	}

	public int getId() {
		return id;
	}

	public Transaction(String type, double amount, double balance,
			String transTime, String description) {
		this.type = type;
		this.amount = amount;
		this.balance = balance;
		this.transTime = transTime;
		this.description = description;
	}

	public Account getAccNo() {
		return account;
	}

	public void setAccNo(Account accNo) {
		this.account = accNo;
	}

	public String print() {
		return (type + "\t" + amount + "\t" + balance + "\t" + transTime + "\t" + description);
	}
}
