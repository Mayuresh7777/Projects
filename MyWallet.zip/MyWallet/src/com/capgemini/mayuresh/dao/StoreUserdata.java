package com.capgemini.mayuresh.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.bean.Transaction;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class StoreUserdata implements StoreDataInterFace {
	EntityManager em = JPAUtil.getEntityManager();
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

	public Account validateUsernameAndPassword(String userName, String password)
			throws RecordNotFoundException {

		em.getTransaction().begin();
		try {
			Account acc = getAcc(userName);
			em.getTransaction().commit();
			if (acc.getPassword().equals(password))
				return acc;
			else
				throw new RecordNotFoundException(
						"Accound Does Not Exist.\nOpen Account First");
		} catch (NoResultException e) {
			em.getTransaction().commit();
			throw new RecordNotFoundException(
					"Accound Does Not Exist.\nOpen Account First");
		}

	}

	public Account getAcc(String userID) throws NoResultException {
		Account acc;
		if (userID.matches("[0-9]{10}"))
			acc = (Account) em
					.createQuery(
							"SELECT a FROM Account a WHERE mobile=:custMob",
							Account.class)
					.setParameter("custMob", Long.parseLong(userID))
					.getSingleResult();
		else
			acc = (Account) em
					.createQuery(
							"SELECT a FROM Account a WHERE email=:custEmail",
							Account.class).setParameter("custEmail", userID)
					.getSingleResult();
		return acc;
	}

	@Override
	public void openAccount(Account acc) {
		em.getTransaction().begin();
		acc.setBalance(1000);
		LocalDateTime now = LocalDateTime.now();
		Transaction trans = new Transaction("CR", 1000, acc.getBalance(),
				dtf.format(now), "Account Opening balance");
		acc.addTransaction(trans);
		em.persist(acc);
		em.getTransaction().commit();
	}

	@Override
	public double showBalance(int accId) throws RecordNotFoundException, NoResultException {
		em.getTransaction().begin();
		Account acc = em.find(Account.class, accId);
		em.getTransaction().commit();
		return acc.getBalance();
	}

	@Override
	public void deposit(int accId, double amount, String desc)
			throws RecordNotFoundException {
		em.getTransaction().begin();
		Account acc = em.find(Account.class, accId);
		if (acc != null) {
			double balance = acc.getBalance();
			acc.setBalance(balance + amount);
			LocalDateTime now = LocalDateTime.now();
			Transaction trans = new Transaction("CR", amount, acc.getBalance(),
					dtf.format(now), desc);
			acc.addTransaction(trans);
			em.merge(acc);
			em.getTransaction().commit();
		} else {
			em.getTransaction().commit();
			throw new RecordNotFoundException("Accound Record not found");
		}

	}

	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		Account acc = em
				.createQuery(
						"SELECT acc from Account acc where acc.accNo= :id",
						Account.class).setParameter("id", userAccId)
				.getSingleResult();
		System.out.println("Your Transactions are....");
		System.out.println("Type\tAmount\tBalance\tTime\t\t\tDescription");
		for (Transaction transaction : acc.getTransactions()) {
			System.out.println(transaction.print());
		}
	}

	@Override
	public void withdraw(int accId, double amount, String desc)
			throws BalanceException, RecordNotFoundException {
		double balance = showBalance(accId);
		if (balance >= amount) {
			em.getTransaction().begin();
			Account acc = em.find(Account.class, accId);
			acc.setBalance(balance - amount);
			LocalDateTime now = LocalDateTime.now();
			Transaction trans = new Transaction("DR", amount, acc.getBalance(),
					dtf.format(now), desc);
			acc.addTransaction(trans);
			em.merge(acc);
			em.getTransaction().commit();
		} else
			throw new BalanceException("Insufficient Balance");

	}

	@Override
	public void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException {
		if (showBalance(source) >= amount) {
			Account acc = em.find(Account.class, source);
			deposit(target, amount, "Deposite by " + acc.getName());
			withdraw(source, amount, "Self withdrawal");
		} else
			throw new BalanceException("Insufficient Balance");

	}

	public boolean validateMobile(long mobile) {
		Account mobileNo;
		try {
			mobileNo = em
					.createQuery(
							"SELECT a FROM Account a WHERE mobile=:custMob",
							Account.class).setParameter("custMob", mobile)
					.getSingleResult();
			return false;
		} catch (NoResultException e) {
			return true;
		}
	}

	public boolean validateEmail(String email) {
		Account emailId;
		try {
			emailId = em
					.createQuery(
							"SELECT a FROM Account a WHERE email=:custEmail",
							Account.class).setParameter("custEmail", email)
					.getSingleResult();
			return false;
		} catch (NoResultException e) {
			return true;
		}
	}
}
