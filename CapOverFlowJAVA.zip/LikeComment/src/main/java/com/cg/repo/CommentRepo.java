package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Comment;

public interface CommentRepo extends CrudRepository<Comment, Integer>
{

}
