package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Post;

public interface PostRepo extends CrudRepository<Post, Integer>
{

}
