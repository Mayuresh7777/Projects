package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Media;

public interface MediaRepo extends CrudRepository<Media, Integer>
{

}
