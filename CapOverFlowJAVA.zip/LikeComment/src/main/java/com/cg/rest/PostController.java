package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Count;
import com.cg.bean.Like;
import com.cg.bean.Media;
import com.cg.bean.Post;
import com.cg.bean.User;
import com.cg.repo.PostRepo;
import com.cg.repo.UserRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/post")
public class PostController
{

    @Autowired
    PostRepo postRepo;

    @Autowired
    UserRepo userRepo;


    @PostMapping(path = "/{id}")
    public ResponseEntity<Post> addPost(@RequestBody Post post, @PathVariable int id)
    {
        User user = userRepo.findById(id).get();
        user.addPost(post);
        user = userRepo.save(user);
        List<Post> posts = user.getPosts();
        post = posts.get(posts.size() - 1);
        Count count = new Count();
        count.setPost(post);
        post.setCount(count);
        for (Media media : post.getMedia())
        {
            media.setMediaPost(post);
        }
        user.addPost(post);
        userRepo.save(user);
        return new ResponseEntity<Post>(post, HttpStatus.OK);
    }


    @PutMapping(path = "", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Post> updatePost(@RequestBody Post post)
    {
        return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
    }


    @GetMapping(path = "/{id}", produces = "application/json")
    public ResponseEntity<Post> getPost(@PathVariable int id)
    {
        return new ResponseEntity<Post>(postRepo.findById(id).get(), HttpStatus.OK);
    }


    @GetMapping(path = "/all", produces = "application/json")
    public ResponseEntity<Iterable<Post>> getAllPost()
    {
        return new ResponseEntity<Iterable<Post>>(postRepo.findAll(), HttpStatus.OK);
    }


    @GetMapping(path = "/all/{id}", produces = "application/json")
    public ResponseEntity<List<Post>> getAllPostOfUser(@PathVariable int id)
    {
        User user = userRepo.findById(id).get();
        return new ResponseEntity<List<Post>>(user.getPosts(), HttpStatus.OK);
    }


    @GetMapping(path = "/count/{id}", produces = "application/json")
    public Count getCount(@PathVariable int id)
    {
        Post post = postRepo.findById(id).get();
        return post.getCount();
    }


    @DeleteMapping(path = "/{id}", produces = "application/json")
    public ResponseEntity<?> deletePost(@PathVariable int id)
    {
        postRepo.deleteById(id);
        return new ResponseEntity<Object>(HttpStatus.OK);
    }


    @GetMapping(path = "/name/{id}")
    public ResponseEntity<User> name(@PathVariable int id)
    {
        Post post = postRepo.findById(id).get();
        User user = post.getUserPost();
        return new ResponseEntity<User>(user, HttpStatus.OK);

    }


    @GetMapping(path = "/check/{postId}/{userId}")
    public ResponseEntity<Boolean> checkUser(@PathVariable("postId") int postId, @PathVariable("userId") int userId)
    {
        Post post = postRepo.findById(postId).get();
        User user = post.getUserPost();
        if (user.getId() == userId)
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        else
            return new ResponseEntity<Boolean>(false, HttpStatus.OK);
    }


    @GetMapping(path = "/likedby/{postId}")
    public ResponseEntity<?> getLikes(@PathVariable("postId") int postId)
    {
        Post post = postRepo.findById(postId).get();
        List<Like> likes = post.getLikes();
        List<User> users = new ArrayList<User>();
        if (likes != null)
            for (Like like : likes)
            {
                users.add(like.getUserLike());
            }
        else
            return new ResponseEntity<String>("no liked post", HttpStatus.BAD_REQUEST);

        return new ResponseEntity<List<User>>(users, HttpStatus.OK);

    }
}
