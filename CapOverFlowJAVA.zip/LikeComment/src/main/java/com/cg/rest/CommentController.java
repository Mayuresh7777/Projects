package com.cg.rest;

import java.util.List;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Comment;
import com.cg.bean.CommentReply;
import com.cg.bean.Count;
import com.cg.bean.Post;
import com.cg.bean.User;
import com.cg.repo.CommentReplyRepo;
import com.cg.repo.CommentRepo;
import com.cg.repo.PostRepo;
import com.cg.repo.UserRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/comment")
public class CommentController
{

    @Autowired
    PostRepo         postRepo;

    @Autowired
    CommentRepo      cRepo;

    @Autowired
    CommentReplyRepo crRepo;

    @Autowired
    UserRepo         userRepo;


    @PostMapping(path = "/{postId}/{userId}")
    public ResponseEntity<Post> doComment(@PathVariable("postId") int postId, @RequestBody Comment comment,
            @PathVariable("userId") int userId)
    {
        User user = userRepo.findById(userId).get();
        Post post = postRepo.findById(postId).get();
        comment.setUserComment(user);
        post.addComment(comment);
        Count count = post.getCount();
        count.setCommentCount(count.getCommentCount() + 1);
        userRepo.save(user);
        return new ResponseEntity<Post>(post, HttpStatus.OK);
    }


    @DeleteMapping(path = "/{postId}/{id}")
    public ResponseEntity<Post> unComment(@PathVariable("postId") int postId, @PathVariable("id") int cId)
    {
        Post post = postRepo.findById(postId).get();
        Comment comment = cRepo.findById(cId).get();
        post.unComment(comment);
        Count count = post.getCount();
        count.setCommentCount(count.getCommentCount() - 1);
        List<CommentReply> replies = comment.getReply();
        long counts = StreamSupport.stream(replies.spliterator(), false).count();
        if (counts != 0)
        {
            count.setCommentCount(count.getCommentCount() - counts);
        }
        return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
    }


    @PostMapping(path = "/reply/{postId}/{userId}/{cId}")
    public ResponseEntity<Post> commentReply(@PathVariable("postId") int postId, @PathVariable("cId") int cId,
            @RequestBody CommentReply reply, @PathVariable("userId") int userId)
    {
        User user = userRepo.findById(userId).get();
        Post post = postRepo.findById(postId).get();
        Comment comment = cRepo.findById(cId).get();
        reply.setUserCommentReply(user);
        comment.addReply(reply);
        Count count = post.getCount();
        count.setCommentCount(count.getCommentCount() + 1);
        userRepo.save(user);
        return new ResponseEntity<Post>(post, HttpStatus.OK);
    }


    @DeleteMapping(path = "/reply/{postId}/{crId}")
    public ResponseEntity<Post> uncommentReply(@PathVariable("postId") int postId, @PathVariable("crId") int crId)
    {
        Post post = postRepo.findById(postId).get();
        CommentReply reply = crRepo.findById(crId).get();
        crRepo.delete(reply);
        Count count = post.getCount();
        count.setCommentCount(count.getCommentCount() - 1);
        return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
    }


    @GetMapping(path = "/{postId}")
    public ResponseEntity<List<Comment>> getComment(@PathVariable("postId") int postId)
    {
        Post post = postRepo.findById(postId).get();
        List<Comment> list = post.getComments();
        return new ResponseEntity<List<Comment>>(list, HttpStatus.OK);
    }


    @GetMapping(path = "/name/{cId}")
    public ResponseEntity<User> getName(@PathVariable("cId") int cId)
    {
        Comment comment = cRepo.findById(cId).get();
        User user = comment.getUserComment();
        System.out.println(user.getFirstName() + " " + user.getLastName());
        return new ResponseEntity<User>(user, HttpStatus.OK);

    }


    @GetMapping(path = "/reply/name/{crId}")
    public ResponseEntity<User> getReplierName(@PathVariable("crId") int crId)
    {
        CommentReply reply = crRepo.findById(crId).get();
        User user = reply.getUserCommentReply();
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }


    @GetMapping(path = "/check/{cId}/{userId}")
    public ResponseEntity<Boolean> checkUser(@PathVariable("cId") int cId, @PathVariable("userId") int userId)
    {
        Comment comment = cRepo.findById(cId).get();
        User user = comment.getUserComment();
        if (user.getId() == userId)
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        else
            return new ResponseEntity<Boolean>(false, HttpStatus.OK);

    }
}