package com.cg.rest;

import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Count;
import com.cg.bean.Like;
import com.cg.bean.Post;
import com.cg.bean.User;
import com.cg.repo.LikeRepo;
import com.cg.repo.PostRepo;
import com.cg.repo.UserRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/like")
public class LikeController
{

    @Autowired
    PostRepo postRepo;

    @Autowired
    LikeRepo likeRepo;

    @Autowired
    UserRepo userRepo;


    @GetMapping(path = "/{postId}/{id}")
    public ResponseEntity<?> doLike(@PathVariable("postId") int postId, @PathVariable("id") int userId)
    {
        User user = userRepo.findById(userId).get();
        Post post = postRepo.findById(postId).get();
        List<Like> likes = post.getLikes();
        Boolean flag = false;
        long counts = StreamSupport.stream(likes.spliterator(), false).count();
        if (counts == 0)
            flag = true;
        else
            loop: for (Like like : likes)
            {
                if (like.getUserLike().equals(user))
                {
                    flag = false;
                    break loop;
                } else
                    flag = true;
            }
        if (flag)
        {
            Like like = new Like();
            like.setPostFromLike(post);
            like.setUserLike(user);
            post.addLike(like);
            Count count = post.getCount();
            count.setLikeCount(count.getLikeCount() + 1);
            return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
        } else
            return new ResponseEntity<String>("You Already like the post", HttpStatus.OK);
    }


    @DeleteMapping(path = "/{postId}/{id}")
    public ResponseEntity<?> unlike(@PathVariable("postId") int postId, @PathVariable("id") int userId)
    {
        User user = userRepo.findById(userId).get();
        Post post = postRepo.findById(postId).get();
        List<Like> likes = post.getLikes();
        Like like = null;
        loop: for (Like liked : likes)
        {
            if (liked.getUserLike().equals(user))
            {
                like = liked;
                break loop;
            }
        }
        if (like != null)
        {
            post.unLike(like);
            Count count = post.getCount();
            count.setLikeCount(count.getLikeCount() - 1);
            return new ResponseEntity<Post>(postRepo.save(post), HttpStatus.OK);
        } else
            return new ResponseEntity<String>("First Like the post", HttpStatus.BAD_REQUEST);
    }


    @GetMapping(path = "/likes/{postId}/{id}")
    public ResponseEntity<?> getLikes(@PathVariable("postId") int postId, @PathVariable("id") int userId)
    {
        User user = userRepo.findById(userId).get();
        List<Like> likes = user.getLikes();
        boolean flag = false;
        if (likes != null)
            for (Like like : likes)
            {
                if (like.getPostFromLike().getId() == postId)
                    flag = true;
            }
        else
            return new ResponseEntity<String>("no liked post", HttpStatus.BAD_REQUEST);

        return new ResponseEntity<Boolean>(flag, HttpStatus.OK);

    }

}
