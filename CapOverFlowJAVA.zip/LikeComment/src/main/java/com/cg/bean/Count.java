package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Counts")
@SequenceGenerator(name = "cntseq", sequenceName = "count_seq", initialValue = 101, allocationSize = 1)
public class Count
{

    @Id
    @Column(name = "count_id", length = 10)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cntseq")
    private int  id;

    private int  likeCount;

    private long commentCount;

    /************** Relationships **************/

    @JsonBackReference(value = "count")
    @OneToOne
    @JoinColumn(name = "post_id")
    private Post post;


    public int getId()
    {
        return id;
    }


    public void setId(int id)
    {
        this.id = id;
    }


    public int getLikeCount()
    {
        return likeCount;
    }


    public void setLikeCount(int likeCount)
    {
        this.likeCount = likeCount;
    }


    public long getCommentCount()
    {
        return commentCount;
    }


    public void setCommentCount(long l)
    {
        this.commentCount = l;
    }


    public Post getPost()
    {
        return post;
    }


    public void setPost(Post post)
    {
        this.post = post;
    }

}
