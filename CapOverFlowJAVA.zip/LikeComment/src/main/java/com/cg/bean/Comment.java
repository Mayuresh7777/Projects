package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Comments")
@SequenceGenerator(name = "cmtseq", sequenceName = "cmt_seq", initialValue = 101, allocationSize = 1)
public class Comment
{

    @Id
    @Column(name = "comment_id", length = 10)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cmtseq")
    private int                id;

    private String             content;

    /********** Relationships *************/

    @JsonBackReference(value = "user-comment")
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User               userComment;

    @JsonBackReference(value = "post-comment")
    @ManyToOne
    @JoinColumn(name = "post_id")
    private Post               postFromComment;

    @JsonManagedReference(value = "comment-reply")
    @OneToMany(mappedBy = "comment", cascade = CascadeType.ALL)
    private List<CommentReply> reply = new ArrayList<CommentReply>();


    public int getId()
    {
        return id;
    }


    public void setId(int id)
    {
        this.id = id;
    }


    public String getContent()
    {
        return content;
    }


    public void setContent(String content)
    {
        this.content = content;
    }


    public Post getPostFromComment()
    {
        return postFromComment;
    }


    public void setPostFromComment(Post postFromComment)
    {
        this.postFromComment = postFromComment;
    }


    public List<CommentReply> getReply()
    {
        return reply;
    }


    public void setReply(List<CommentReply> reply)
    {
        this.reply = reply;
    }


    public void addReply(CommentReply reply)
    {
        reply.setComment(this);
        this.getReply().add(reply);
    }


    public void removeReply(CommentReply reply)
    {
        this.getReply().remove(reply);
    }


    public User getUserComment()
    {
        return userComment;
    }


    public void setUserComment(User userComment)
    {
        this.userComment = userComment;
    }

}
