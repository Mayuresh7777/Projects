package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.websocket.ClientEndpoint;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "media")
@SequenceGenerator(name = "mediaseq", sequenceName = "media_seq", initialValue = 101, allocationSize = 1)
public class Media
{

    @Id
    @Column(name = "media_id", length = 10)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mediaseq")
    private int                           id;

    @Lob
    private String                        base64;

    @JsonBackReference(value = "post-media")
    @ManyToOne
    @JoinColumn(name = "post_id")
    private Post                          mediaPost;


    public int getId()
    {
        return id;
    }


    public void setId(int id)
    {
        this.id = id;
    }


    public Post getMediaPost()
    {
        return mediaPost;
    }


    public void setMediaPost(Post mediaPost)
    {
        this.mediaPost = mediaPost;
    }


    public String getBase64()
    {
        return base64;
    }


    public void setBase64(String base64)
    {
        this.base64 = base64;
    }

}
