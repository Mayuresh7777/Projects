package com.cg.step;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Enquiry;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EnquiryStepDefinition {
	WebDriver driver;
	Enquiry enquiry;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.close();
	}

	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		enquiry = new Enquiry(); // instantiate bean object
		PageFactory.initElements(driver, enquiry);// for mapping web with bean
		driver.get("C:\\Users\\mayuress\\BDD\\MayureshShinde_173560\\html\\Receipe_class_registration.html");
		Thread.sleep(1000);
	}

	@Then("^Validate page title$")
	public void validate_page_title() throws Throwable {
		String title = "Online Cooking Class Enquiry Form";
		assertEquals(driver.getTitle(), title); // verifying title
		Thread.sleep(10000);
	}

	@Then("^Validate text$")
	public void validate_text() throws Throwable {
		String expectedText = "Online Cooking School";
		String actualText = driver.findElement(By.tagName("span")).getText(); //getting text form page
		assertTrue(actualText.contains(expectedText)); // verifying text
		Thread.sleep(10000);
	}

	@When("^User enters firstname$")
	public void user_enters_firstname() throws Throwable {
		enquiry.setFirstName("");
	}

	@Then("^validate firstname$")
	public void validate_firstname() throws Throwable {
		enquiry.clickEnquire();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();//accepting the alert
		Thread.sleep(10000);
	}

	@When("^User enters lastname$")
	public void user_enters_lastname() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("");
	}

	@Then("^validate lastname$")
	public void validate_lastname() throws Throwable {
		enquiry.clickEnquire();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();//accepting the alert
		Thread.sleep(10000);
	}

	@Then("^User enters email$")
	public void user_enters_email() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
	}

	@When("^User enters character$")
	public void user_enters_character() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("char");
	}

	@Then("^Validate mobile$")
	public void validate_mobile() throws Throwable {
		enquiry.clickEnquire();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();//accepting the alert
		Thread.sleep(10000);
	}

	@When("^User enters mobile$")
	public void user_enters_mobile() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("123456789");
	}

	@Then("^User selects interest$")
	public void user_selects_interest() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		Thread.sleep(10000);
	}

	@Then("^User selects city$")
	public void user_selects_city() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		enquiry.setCity("Mumbai");
		Thread.sleep(10000);
	}

	@Then("^User selects mode$")
	public void user_selects_mode() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		enquiry.setCity("Mumbai");
		enquiry.setMode("In house training");
		Thread.sleep(10000);
	}

	@Then("^User selects duration$")
	public void user_selects_duration() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		enquiry.setCity("Mumbai");
		enquiry.setMode("In house training");
		enquiry.setDuration("6 months");
		Thread.sleep(10000);
	}

	@When("^User enters enquiry details$")
	public void user_enters_enquiry_details() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		enquiry.setCity("Mumbai");
		enquiry.setMode("In house training");
		enquiry.setDuration("6 months");
	}

	@Then("^Validate enquiry$")
	public void validate_enquiry() throws Throwable {
		enquiry.submitForm();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();//accepting the alert
		Thread.sleep(10000);
	}

	@When("^User enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		enquiry.setFirstName("Mayuresh");
		enquiry.setLastname("Shinde");
		enquiry.setEmail("shinde@gmail.com");
		enquiry.setContact("9167968584");
		enquiry.setInterest("Non-Veg");
		enquiry.setCity("Mumbai");
		enquiry.setMode("In house training");
		enquiry.setDuration("6 months");
		enquiry.setEnquiry("Something Something");
	}

	@Then("^show success meassage$")
	public void show_success_meassage() throws Throwable {
		enquiry.submitForm();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();//accepting the alert
		Thread.sleep(10000);
	}

	@Then("^Verify message$")
	public void verify_message() throws Throwable {
		String expectedText = "Our location representative will contact you soon.";
		String actualText = driver.findElement(By.tagName("h3")).getText();
		assertEquals(actualText, expectedText);
	}
}
