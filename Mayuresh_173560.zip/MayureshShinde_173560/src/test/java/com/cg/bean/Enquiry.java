package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Enquiry {
	// Web Elements

	@FindBy(id = "fname")
	private WebElement firstName;

	@FindBy(id = "lname")
	private WebElement lastname;

	@FindBy(id = "emails")
	private WebElement email;

	@FindBy(id = "mobile")
	private WebElement contact;

	@FindBy(name = "D5")
	private WebElement city;

	@FindBy(name = "D6")
	private WebElement interest;

	@FindBy(name = "D4")
	private WebElement mode;

	@FindBy(xpath = "/html/body/form/table/tr[8]/td[2]/select")
	private WebElement duration;

	@FindBy(id = "enqdetails")
	private WebElement enquiry;

	@FindBy(tagName = "form")
	private WebElement form;

	@FindBy(id = "Submit1")
	private WebElement enquireNow;

	// Setters for Web Element
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);
	}

	public void setCity(String selectedCity) {
		Select select = new Select(city);
		select.selectByVisibleText(selectedCity);
	}

	public void setInterest(String selectedinterest) {
		Select select = new Select(interest);
		select.selectByVisibleText(selectedinterest);
	}

	public void setMode(String selectedMode) {
		Select select = new Select(mode);
		select.selectByVisibleText(selectedMode);
	}

	public void setDuration(String selectedDuration) {
		Select select = new Select(duration);
		select.selectByVisibleText(selectedDuration);
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

	public void submitForm() {
		this.form.submit();
	}

	public void clickEnquire() {
		this.enquireNow.click();
	}

}
