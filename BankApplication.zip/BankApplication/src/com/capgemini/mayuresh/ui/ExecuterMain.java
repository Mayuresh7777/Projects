package com.capgemini.mayuresh.ui;

import java.util.Scanner;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;
import com.capgemini.mayuresh.service.ValidateInterface;
import com.capgemini.mayuresh.service.ValidateUserInput;

public class ExecuterMain
{

    public static void main(String[] args)
    {
        String ch;
        boolean isValid;
        String firstChoice;
        String userName;
        String password;
        String amount;
        String targetAccId;
        ValidateInterface userInput = new ValidateUserInput();
        Scanner sc = new Scanner(System.in);
        Account requstedAcc = null;
        System.out.println("Mayuresh Bank Welcome you");
        while (true)
        {
            while (true)
            {
                System.out.println("1.	Log in\n2.	Create Account");
                firstChoice = sc.next();
                isValid = userInput.validateEntry(firstChoice);
                if (isValid)
                    break; // if user enter valid input then break
                else
                    System.out.println("Please enter Valid Choice 1 or 2");
            }
            switch (firstChoice)
            {
            case "1":
                floop: while (true)
                {
                    System.out.println("Please Log In");
                    while (true)
                    {

                        System.out.println("Enter MobileNo");
                        userName = sc.next();
                        // to validate user Mobile No
                        isValid = userInput.validateMobile(userName);
                        if (isValid)
                            break;// if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid Mobile without +91 (eg. 9167968584)");
                    }
                    while (true)
                    {
                        System.out.println("Enter Password");
                        password = sc.next();
                        // to validate user Mobile No
                        isValid = userInput.validatePassword(password);
                        if (isValid)
                            break;// if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid password (eg. Mayuresh123@)");
                    }
                    try
                    {
                        requstedAcc = userInput.validateUsernameAndPassword(
                                userName, password);
                        System.out.println("Login Successfully");
                        System.out.println("Welcome Back " + requstedAcc.getName() + "\nA/c No :" + requstedAcc
                                .getAccNo());
                    } catch (RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    if (requstedAcc != null)
                        break;// if user enter valid input then break
                    else
                        break floop;
                }

                break;
            case "2":
                userInput.createAccount();
                while (true)
                {
                    System.out.println("Please Log In");
                    while (true)
                    {

                        System.out.println("Enter MobileNo");
                        userName = sc.next();
                        // to validate user Mobile No
                        isValid = userInput.validateMobile(userName);
                        if (isValid)
                            break;// if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid Mobile without +91 (eg. 9167968584)");
                    }
                    while (true)
                    {
                        System.out.println("Enter Password");
                        password = sc.next();
                        // to validate user Mobile No
                        isValid = userInput.validatePassword(password);
                        if (isValid)
                            break;// if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid password (eg. Mayuresh123@)");
                    }
                    try
                    {
                        requstedAcc = userInput.validateUsernameAndPassword(
                                userName, password);
                        System.out.println("Login Successfully");
                        System.out.println("Welcome Back " + requstedAcc.getName() + "\nA/c No :" + requstedAcc
                                .getAccNo());
                    } catch (RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    if (requstedAcc != null)
                        break;// if user enter valid input then break
                    else
                        System.out.println("Incorrect userName/Password");
                }
                break;
            default:
                break;
            }

            loop: while (true)
            {
                if (requstedAcc == null)
                    break loop;
                else
                    while (true)
                    {

                        System.out
                                .println("1.	Show Balance\n2.	Deposite\n3.	Withdraw"
                                        + "\n4.	Fund Transfer\n5.	Show Transaction\n6.	Log out\n7.	Exit");
                        ch = sc.next();
                        isValid = userInput.validateEntry(ch);
                        if (isValid)
                            break; // if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid Choice 1 to 6");
                    }
                switch (ch)
                {
                case "1":
                    try
                    {
                        System.out.println("Your Blanace is "
                                + userInput.showBalance(requstedAcc
                                        .getAccNo()));
                    } catch (NumberFormatException
                            | RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    break;
                case "2":
                    while (true)
                    {
                        System.out.println("Enter Amount");
                        amount = sc.next();
                        isValid = userInput.validateAmount(amount);
                        if (isValid)
                            break; // if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Amount eg.4000");
                    }
                    try
                    {
                        userInput.deposit(requstedAcc.getAccNo(),
                                Double.parseDouble(amount));
                        System.out.println("Transaction Successful");
                    } catch (NumberFormatException
                            | RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    break;
                case "3":
                    while (true)
                    {
                        System.out.println("Enter Amount");
                        amount = sc.next();
                        isValid = userInput.validateAmount(amount);
                        if (isValid)
                            break; // if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Amount eg.4000");
                    }
                    try
                    {
                        userInput.withdraw(requstedAcc.getAccNo(),
                                Double.parseDouble(amount));
                        System.out.println("Transaction Successful");
                    } catch (NumberFormatException | BalanceException
                            | RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    break;
                case "4":
                    while (true)
                    {
                        System.out.println("Enter receipent Account Id");
                        targetAccId = sc.next();
                        isValid = userInput.validateAccId(targetAccId);
                        if (isValid)
                            break; // if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Valid Account Id eg.1234567");
                    }
                    while (true)
                    {
                        System.out.println("Enter Fund transfer Amount");
                        amount = sc.next();
                        isValid = userInput.validateAmount(amount);
                        if (isValid)
                            break; // if user enter valid input then break
                        else
                            System.out
                                    .println("Please enter Amount eg.4000");
                    }
                    userInput.fundTransfer(requstedAcc.getAccNo(),
                            Integer.parseInt(targetAccId),
                            Double.parseDouble(amount));
                    System.out.println("Transaction Successful");
                    break;
                case "5":
                    try
                    {
                        userInput.Showtransaction(requstedAcc.getAccNo());
                    } catch (NumberFormatException
                            | RecordNotFoundException e)
                    {
                        System.out.println(e);
                    }
                    break;
                case "6":
                    requstedAcc = null;
                    break loop;
                case "7":
                    System.exit(0);
                    break;
                default:
                    break;
                }
            }
        }
       
    }
}