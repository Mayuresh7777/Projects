package com.capgemini.mayuresh.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.dao.StoreUserdata;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class AccountTest {
	StoreUserdata accountDao = null;

	@Before
	public void setUp() throws Exception {

		accountDao = new StoreUserdata();
	}

	@After
	public void tearDown() throws Exception {
		accountDao = null;
	}

	@Test
	public void testShowbalanceValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = accountDao.showBalance(acc.getAccNo());
			Assert.assertNotNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testShowbalanceInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = accountDao.showBalance(12345);
			Assert.assertNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testDepositValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			double upadatedAmount=acc.getBalance();
			amount+=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testDepositInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			Assert.assertFalse(amount==amount+2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.withdraw(acc.getAccNo(), 4000);
			double upadatedAmount=acc.getBalance();
			amount-=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com","Mayu123@");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			Assert.assertFalse(amount==amount-2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
}
