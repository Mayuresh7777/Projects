package com.capgemini.mayuresh.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.bean.Transaction;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class StoreUserdata implements StoreDataInterFace {
	// To save customer Data in map
	Map<Integer, Account> accounts = new HashMap<Integer, Account>();
	private ArrayList<Transaction> txns = new ArrayList<Transaction>();;
	private static int accountCounter = 1234501;

	@Override
	public void openAccount(Account acc) {
		acc.setAccNo(accountCounter);
		acc.setBalance(1000);
		accounts.put(acc.getAccNo(), acc);// Putting customer in map
		System.out
				.println("Customer information saved successfully.");
		accountCounter++;
	}

	public Account validateUsernameAndPassword(String userName, String password) throws RecordNotFoundException {
		for (Account acc : accounts.values()) {
			if (Long.parseLong(userName) == acc.getMobile() && password.equals(acc.getPassword())) {
				return acc;
			}
		}
		throw new RecordNotFoundException(
				"Accound Does Not Exist.\nOpen Account First");
	}

	@Override
	public double showBalance(int accId) throws RecordNotFoundException {
		Account acc = accounts.get(accId);
		if (acc != null)
			return acc.getBalance();
		else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	@Override
	public void deposit(int accID, double amount)
			throws RecordNotFoundException {
		Account acc = accounts.get(accID);
		if (acc != null) {
			double amt = acc.getBalance();
			acc.setBalance(amt + amount);
			txns.add(new Transaction(accID, "CR", amount, (amt + amount)));
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		if (txns != null) {
			System.out.println("Type\tAmount\tBalance");
			for (Transaction transaction : txns) {
				if (transaction.equals(new Transaction(userAccId, null, 0, 0)))
					System.out.println(transaction.print());
			}
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	@Override
	public void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException {
		Account acc = accounts.get(accId);
		if (acc != null) {
			double amt = acc.getBalance();

			if (amount <= amt) {
				acc.setBalance(amt - amount);
				txns.add(new Transaction(accId, "DR", amount, (amt - amount)));
			} else
				throw new BalanceException("Insufficient Balance");
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	public void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException {
		withdraw(source, amount);
		deposit(target, amount);

	}

	public boolean validateMobile(long mobile) {
		for (Account acc : accounts.values()) {
			if (mobile == acc.getMobile()) {
				return false;
			}
		}
		return true;
	}
	public boolean validateEmail(String email) {
		for (Account acc : accounts.values()) {
			if (email.equals(acc.getEmail())) {
				return false;
			}
		}
		return true;
	}
}
