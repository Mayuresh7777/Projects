package com.capgemini.mayuresh.bean;

public class Transaction
{
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Transaction)
            return ((Transaction) obj).accNo == accNo;
        else
            return false;
    }

    private int accNo;


    public int getAccNo()
    {
        return accNo;
    }

    private String type;
    private double amount, balance;


    public Transaction()
    {
    }


    public Transaction(int accNo, String type, double amount, double balance)
    {
        this.accNo = accNo;
        this.type = type;
        this.amount = amount;
        this.balance = balance;
    }


    public String print()
    {
        return (type + "\t" + amount + "\t" + balance);
    }
}
