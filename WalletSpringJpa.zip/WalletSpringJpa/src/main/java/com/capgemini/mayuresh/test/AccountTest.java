package com.capgemini.mayuresh.test;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.mayuresh.dao.StoreDataInterFace;
import com.capgemini.mayuresh.dao.StoreUserdata;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class AccountTest {

	ApplicationContext context = new ClassPathXmlApplicationContext("appCtx.xml");
	StoreDataInterFace data= (StoreDataInterFace) context.getBean("data");
	@Test
	public void testShowbalanceValidDetails() {
		try {
			double amount = data.showBalance(1234501);
			Assert.assertNotNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

	@Test(expected = NullPointerException.class)
	public void testShowbalanceInvalidDetails() throws RecordNotFoundException {
		data.showBalance(12345);
	}

	@Test
	public void testDepositValidDetails() {
		try {
			double amount = data.showBalance(1234501);
			data.deposit(1234501, 4000, "Self Deposite");
			double upadatedAmount = data.showBalance(1234501);
			amount += 4000;
			Assert.assertTrue(amount == upadatedAmount);
			;
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

	@Test
	public void testDepositInvalidDetails() {
		try {
			double amount = data.showBalance(1234501);
			data.deposit(1234501, 4000, "Self Deposite");
			Assert.assertFalse(amount == amount + 2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

	@Test
	public void testWithdrawValidDetails() {
		try {
			double amount = data.showBalance(1234501);
			data.withdraw(1234501, 4000, "Self Withdrawal");
			double upadatedAmount = data.showBalance(1234501);
			amount -= 4000;
			Assert.assertTrue(amount == upadatedAmount);
			;
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}

	@Test
	public void testWithdrawInvalidDetails() {
		try {
			double amount = data.showBalance(1234501);
			data.withdraw(1234501, 4000, "Self Withdrawal");
			Assert.assertFalse(amount == amount - 2000);
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}
}
