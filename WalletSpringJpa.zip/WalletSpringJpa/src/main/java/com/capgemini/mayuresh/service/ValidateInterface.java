package com.capgemini.mayuresh.service;

import java.util.ArrayList;
import java.util.Map;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public interface ValidateInterface {
	// Matches pattern string
	String ENTRY = "[1-7]{1}";
	String FIRST_CHOICE = "[1-2]{1}";
	String ACC_NO = "[0-9]{7,8}";
	String PASSWORD = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})";
	String AMOUNT = "[0-9]{1,10}";
	String USER_NAME_PATTERN = "^[\\p{L} .'-]+$";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String EMAIL_PATTERN = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";

	// String CUST_ID="[0-9]{1,4}";

	// creating methods for validates user Input
	boolean validateUserName(String userName);

	boolean validatePassword(String password);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);

	boolean validateEntry(String ch);

	boolean validateAccId(String userAccId);

	void openAccount(Account acc);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accId, double amount, String desc) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount, String desc) throws BalanceException, RecordNotFoundException;

	void fundTransfer(int source, int target, double amount) throws BalanceException, RecordNotFoundException;
}
