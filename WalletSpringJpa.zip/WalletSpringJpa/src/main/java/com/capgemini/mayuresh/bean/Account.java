package com.capgemini.mayuresh.bean;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "account")
@Component
@Scope("prototype")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "acc_generator")
	@SequenceGenerator(name = "acc_generator", sequenceName = "seq_accno")
	@Column(name = "ACCNO", updatable = false, nullable = false)
	private int accNo; // backend will generate random code and assign it when
						// openAccount()

	@Column(name = "NAME", length = 50)
	private String name;

	@Column(name = "MOBILE", length = 10)
	private long mobile;

	@Column(name = "EMAIL", length = 50)
	private String email;

	@Column(name = "PASSWORD", length = 50)
	private String password;

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	@Column(name = "BALANCE")
	protected double balance;// opening account balance is 1000rs that will
								// deposited when openAccount()
								// Comparator<Transaction> byId = (Transaction
								// t1, Transaction t2) -> t1
	// .getId() - t2.getId();
	@OneToMany(mappedBy = "account", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Transaction> transactions = new ArrayList<Transaction>();

	public Account() {
	}

	public Account(String name, long mobile, String email, String password) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}

	@Override
	public String toString() {
		return "A/C No = " + accNo + "\nName = " + name + "\nMobile = " + mobile + "\nEmail = " + email + "\nBalance = "
				+ balance;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(ArrayList<Transaction> transactions) {
		this.transactions = transactions;
	}

	public void addTransaction(Transaction trans) {
		trans.setAccNo(this); // this will avoid nested cascade
		this.getTransactions().add(trans);
	}
}
