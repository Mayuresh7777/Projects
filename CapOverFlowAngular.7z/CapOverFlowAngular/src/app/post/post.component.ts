import { Component, OnInit, Input } from '@angular/core';
import { UserModel } from '../models/User';
import { PostModel } from '../models/Post';
import { PostService } from '../service/post.service';
import { Router } from '@angular/router';
import { MediaModel } from '../models/Media';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  currentUser: UserModel;

  @Input() post: PostModel;

  urls = [];

  constructor(private routes: Router, private postService: PostService) {
    console.log("in post Constuctor");
    this.currentUser = new UserModel();
    this.post = new PostModel();
    this.post.media = [];
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
  }
  ngOnInit() {
  }

  posting() {
    if (this.post.content != undefined && this.post.content.match("[a-zA-Z!@#$%^&*(),.?:{}|<>]{1,100}")) {
      for (let url of this.urls) {
        let media = new MediaModel();
        media.base64 = url;
        this.post.media.push(media);
        console.log("Url length " + url.length);
      }
      this.postService.addPost(this.currentUser.id, this.post).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
      this.urls = [];
    } else {
      confirm("Please add some content..");
    }
  }

  onSelectFile(event) {
    let files = event.target.files;
    if (files) {
      for (let file of files) {
        let reader = new FileReader();

        reader.onload = (e: any) => {
          this.urls.push(e.target.result);
        }
        reader.readAsDataURL(file);
      }
    }
    console.log(this.urls);
  }

  deleteImage(index: number) {
    console.log("index " + index);
    this.urls.splice(index, 1);
  }
}
