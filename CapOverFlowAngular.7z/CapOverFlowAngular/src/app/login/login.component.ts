import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { UserModel } from '../models/User';
import { LoginService } from '../service/login.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
declare var grecaptcha: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: FormGroup;
  username: String;
  pass: String;
  valid: boolean;
  submitted: boolean = false;
  captchaError: boolean = false;
  user: UserModel;
  constructor(private routes: Router, private loginService: LoginService, private formBuilder: FormBuilder) {
    if (this.loginService.isLogged()) {
      this.routes.navigate(['/home']);
    }
    
  }

  ngOnInit() {
    this.valid = false;
    this.login = this.formBuilder.group({
      username: ['', Validators.required],
      pass: ['', Validators.required]
    });
  }

  checkLogin() {
    this.submitted = true;
    if (this.login.invalid) {
      return;
    }
    this.username = this.login.controls.username.value;
    this.pass = this.login.controls.pass.value;
    this.loginService.getUser(this.username, this.pass).subscribe(
      data => {
        this.user = data;
        if (this.user != null) {
          this.loginService.setUser(this.user);
          this.validate(this.user);
        }
        else
          this.valid = true;
        
      },
      error => console.log('ERROR: ' + error));
  }
  validate(user: UserModel) {
    this.user = user;
    console.log(this.user);
    console.log("Login works");
    this.routes.navigate(['/home']).then(() => {
      window.location.reload();
    });
  }

  signup() {
    this.routes.navigate(['/register']);
  }
}