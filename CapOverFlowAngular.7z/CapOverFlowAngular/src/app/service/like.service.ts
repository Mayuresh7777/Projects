import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostModel } from '../models/Post';
import { Observable } from 'rxjs';
import { LikeModel } from '../models/Like';

@Injectable({
  providedIn: 'root'
})
export class LikeService {

  private baseUrl = 'http://localhost:7778/like';

  constructor(private http: HttpClient) { }

  like(postId: number, userId: number): Observable<Object> {
    return this.http.get<Object>(`${this.baseUrl}/${postId}/${userId}`);
  }

  unlike(postId: number, userId: number): Observable<Object> {
    return this.http.delete<Object>(`${this.baseUrl}/${postId}/${userId}`);
  }

  getLike(postId: number, userId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/likes/${postId}/${userId}`);
  }

}
