import { Injectable, ApplicationModule } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from '../models/User';

const TOKEN = 'USER';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  user: UserModel;

  isLogin : boolean;

  private baseUrl = 'http://localhost:7778/user';

  constructor(private http: HttpClient) {
    this.user = new UserModel();
  }

  getUser(username: String, pass: String): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/${username}/${pass}`);
  }

  getUserById(id: number): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.baseUrl}/${id}`);
  }

  addUser(user: UserModel): Observable<UserModel> {
    return this.http.post<UserModel>(`${this.baseUrl}`, user);
  }

  updateUser(user: UserModel): Observable<UserModel> {
    return this.http.put<UserModel>(`${this.baseUrl}`, user);
  }

  validateEmail(email: String): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/email/${email}`);
  }

  validateMobile(mobile: String): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/mobile/${mobile}`);
  }

  setUser(user: UserModel) {
    this.user = user;
    localStorage.setItem(TOKEN, JSON.stringify(user));
  }

  isLogged() {
    return localStorage.getItem(TOKEN) != null;
  }

  logout() {
    localStorage.removeItem(TOKEN);
  }
}