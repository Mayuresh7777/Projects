export class LikeModel {
    public id: number;
}