import { CountModel } from './count';
import { MediaModel } from './Media';


export class PostModel {
    public id: number;

    public content: String;

    public media : MediaModel[];

    public count: CountModel;
}