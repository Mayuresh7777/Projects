export class MediaModel {
    public id: number;

    public base64 = String;
}