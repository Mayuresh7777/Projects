export class UserModel {
    public id: number;

    public firstName: String;

    public lastName: String;

    public email: String;

    public mobile: String;

    public password: String;
}