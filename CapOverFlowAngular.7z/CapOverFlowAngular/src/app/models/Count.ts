export class CountModel {
    public id: number;

    public likeCount : number;

    public commentCount : number;
}