import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  currentUser: UserModel;
  user: UserModel;
  isEditing: boolean;
  userId: string;
  id: number;

  constructor(private router: ActivatedRoute, private servive: LoginService, private routes: Router) {
    this.user = new UserModel();
    this.currentUser = new UserModel();

    this.routes.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
  }
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
    this.userId = this.router.snapshot.queryParamMap.get('id');
    this.fetchUser();
  }

  fetchUser() {
    console.log("debug" + typeof this.userId);
    if (this.userId == undefined || this.userId == "") {
      this.routes.navigate(['/home']);
    } else if (Number.parseInt(this.userId) == this.currentUser.id) {
      this.user = this.currentUser;
      this.id = this.user.id;
    } else {
      this.id = Number.parseInt(this.userId);
      this.servive.getUserById(Number.parseInt(this.userId)).subscribe(
        data => {
          this.user = data as UserModel;
        },
        error => console.log('ERROR: ' + error));
    }
    console.log("profile Id : " + this.user.id + " " + this.user.firstName);
  }

  edit() {
    this.isEditing = true;

  }
  cancel() {
    this.isEditing = false;
  }
}
