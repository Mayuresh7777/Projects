import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from './service/login.service';
import { UserModel } from './models/User';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  currentUser : UserModel;


  title = 'LikeCommentAngular';

  constructor(private routes: Router,public loginService: LoginService, private router: ActivatedRoute) {
    console.log("inside cons of app");
    this.currentUser = new UserModel();
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
    console.log("Logged :" +this.currentUser);
  }

   ngOnInit() {
    console.log("inside init of app");
    this.currentUser = JSON.parse(localStorage.getItem("USER"));
    console.log("Logged :" +this.currentUser);
  }

  logout() {
    console.log("Inside Log Out");
    this.loginService.logout();
    window.location.pathname = "./login";
  }

}