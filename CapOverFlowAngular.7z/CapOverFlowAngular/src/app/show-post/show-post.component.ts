import { Component, OnInit, Input } from '@angular/core';
import { PostService } from '../service/post.service';
import { PostModel } from '../models/Post';
import { UserModel } from '../models/User';
import { LikeService } from '../service/like.service';
import { LikeModel } from '../models/Like';
import { CountModel } from '../models/count';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-post',
  templateUrl: './show-post.component.html',
  styleUrls: ['./show-post.component.css']
})
export class ShowPostComponent implements OnInit {

  user: UserModel;
  posts: PostModel[] = [];
  @Input() userId: number;
  name: String = "";
  map = new Map<number, UserModel>();
  likeMap = new Map<number, boolean>();
  commentMap = new Map<number, boolean>();
  likeCount = new Map<number, number>();
  commentCount = new Map<number, number>();
  flagMap = new Map<number, boolean>();
  likes: LikeModel[] = [];
  searchLike: LikeModel;
  showComment: boolean = false;
  likedByMap = new Map<number, boolean>();
  likedByNames = new Map<number, String[]>();
  likedNames: String[] = [];
  constructor(private postService: PostService, private likeService: LikeService, private sanitizer: DomSanitizer, private router: Router) {
    this.user = JSON.parse(localStorage.getItem("USER"));
    this.fetchPosts();
    console.log("in Show post Constuctor");
  }

  ngOnInit() {
  }


  fetchPosts() {
    (this.userId != undefined ? this.postService.getAllPostOfUser(this.userId) : this.postService.getAll()).subscribe(
      data => {
        this.setPosts(data);
        for (let p of data) {
          this.getName(p.id);
          this.setLikeMap(p.id);
          this.setCommentMap(p.id);
          this.setCount(p.id, p.count);
          this.checkUser(p.id);
          this.setLikedByMap(p.id);
          this.fetchLikedByNames(p.id);
        }
        this.fetchLikes(data);
        console.log("Post fetched Successfully");
      },
      error => console.log('ERROR: ' + error));
  }

  checkUser(id: number) {
    this.postService.checkUser(id, this.user.id).subscribe(
      data => {
        this.setFlag(id, data);
      },
      error => console.log('ERROR: ' + error));
  }

  setLikedByMap(id: number) {
    this.likedByMap.set(id, false);
  }

  toggleLikedBy(id: number) {
    let temp = this.likedByMap.get(id);
    this.likedByMap.set(id, !temp);
  }
  setFlag(id: number, flag: boolean) {
    this.flagMap.set(id, flag);
  }
  setCount(id: number, count: CountModel) {
    this.likeCount.set(id, count.likeCount);
    this.commentCount.set(id, count.commentCount);
  }

  fetchLikes(posts: PostModel[]) {
    console.log("Id" + this.user.id);
    for (let post of posts) {
      this.likeService.getLike(post.id, this.user.id).subscribe(
        data => {
          if (data)
            this.likeMap.set(post.id, data);
        },
        error => console.log('ERROR: ' + error));
    }
  }

  fetchLikedByNames(id: number) {
    this.postService.likedBy(id).subscribe(
      data => {
        this.setLikeByNames(id, data);
      },
      error => console.log('ERROR: ' + error));
  }

  setLikeByNames(id: number, users: UserModel[]) {

    for (let user of users) {
      this.likedNames.push(user.firstName + " " + user.lastName);
    }
    this.likedByNames.set(id, this.likedNames);
    this.likedNames = [];
  }

  setLikes(likes: LikeModel[]) {
    this.likes = likes;
  }

  setPosts(posts: PostModel[]) {
    this.posts = posts;
    console.log(this.posts);
  }

  getName(id: number) {
    console.log("inside name");
    this.postService.getName(id).subscribe(
      data => {
        this.setMap(id, data);
      },
      error => console.log('ERROR: ' + error));
  }

  setLikeMap(id: number) {
    this.likeMap.set(id, false);
  }
  setCommentMap(id: number) {
    this.commentMap.set(id, false);
  }
  setName(name: String) {
    this.name = name;
    console.log(this.name);
  }

  setMap(id: number, user: UserModel) {
    this.map.set(id, user);
  }
  like(id: number) {
    this.likeService.like(id, this.user.id).subscribe(
      data => {
        console.log(data);
        this.likeMap.set(id, true);
        this.likeCount.set(id, this.likeCount.get(id) + 1);
        this.likedByNames.get(id).push(this.user.firstName + " " + this.user.lastName);
      },
      error => console.log('ERROR: ' + error));
  }
  unlike(id: number) {
    this.likeService.unlike(id, this.user.id).subscribe(
      data => {
        console.log(data);
        this.likeMap.set(id, false);
        this.likeCount.set(id, this.likeCount.get(id) - 1);
        this.likedByNames.get(id).splice(this.likedByNames.get(id).indexOf(this.user.firstName + " " + this.user.lastName), 1);
      },
      error => console.log('ERROR: ' + error));
  }

  getFlag(id: number) {
    return this.likeMap.get(id);
  }

  toggle(id: number) {
    for (let post of this.posts) {
      if (post.id != id)
        this.commentMap.set(post.id, false);
    }
    this.showComment = !this.commentMap.get(id);
    this.commentMap.set(id, this.showComment);
    localStorage.setItem("POSTID", JSON.stringify(id));
  }

  deletePost(id: number) {
    if (confirm("Press Ok to delete Post"))
      this.postService.removePost(id).subscribe(
        data => {
          console.log(data);
          window.location.reload();
        },
        error => console.log('ERROR: ' + error));
  }

  transform(base64: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(base64);
  }
}
